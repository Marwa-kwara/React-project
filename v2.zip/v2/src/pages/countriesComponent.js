// import { AllCountriesContext } from "../components/AllCountriesContext";
// import { useContext } from "react";
// import "../App.css";

// const CountriesComponent = () => {
//   const [countriesList] = useContext(AllCountriesContext);
//   return countriesList.map((country) => {
//     return (
//       <div className="countryListContainer">
//         <img className="countriesListImg" src={country.flag} alt={""} />
//         <h2>Country name : {country.name} </h2>
//       </div>
//     );
//   });
// };
// export default CountriesComponent;
